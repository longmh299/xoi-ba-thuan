import { useNavigate } from "react-router-dom";
import { useCartStore } from "../../store/cart.store";

export default function CartBar() {
  const navigate = useNavigate();

  const items = useCartStore(
    (state) => state.items
  );

  const totalItems = useCartStore(
    (state) => state.totalItems()
  );

  const totalPrice = useCartStore(
    (state) => state.totalPrice()
  );

  if (items.length === 0) return null;

  return (
    <div
      className="
        fixed
        bottom-5
        left-4
        right-4
        z-40
      "
    >
      <button
        onClick={() => navigate("/cart")}
        className="
          w-full
          h-16
          rounded-2xl
          bg-green-600
          text-white
          shadow-xl
          px-5
          flex
          items-center
          justify-between
          active:scale-95
          transition
        "
      >
        <div>
          <p className="font-bold">
            🛒 {totalItems} món
          </p>

          <p className="text-sm opacity-90">
            Xem giỏ hàng
          </p>
        </div>

        <p className="text-xl font-bold">
          {totalPrice.toLocaleString("vi-VN")}đ
        </p>
      </button>
    </div>
  );
}