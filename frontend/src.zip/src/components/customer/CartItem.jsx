import { useCartStore } from "../../store/cart.store";

export default function CartItem({ item }) {
  const increase = useCartStore(
    (state) => state.increase
  );

  const decrease = useCartStore(
    (state) => state.decrease
  );

  const remove = useCartStore(
    (state) => state.remove
  );

  return (
    <div
      className="
        bg-white
        rounded-3xl
        p-4
        shadow
      "
    >
      <div className="flex justify-between">

        <div>

          <h2 className="text-xl font-bold">
            {item.foodName}
          </h2>

          <p className="text-gray-500 mt-1">
            {item.variantName}
          </p>

          <p className="text-green-600 font-bold mt-2">
            {item.price.toLocaleString("vi-VN")}đ
          </p>

        </div>

        <button
          onClick={() =>
            remove(item.foodVariantId)
          }
          className="text-red-500 text-xl"
        >
          🗑
        </button>

      </div>

      <div className="flex items-center gap-3 mt-4">

        <button
          onClick={() =>
            decrease(item.foodVariantId)
          }
          className="
            w-10
            h-10
            rounded-full
            bg-gray-200
          "
        >
          -
        </button>

        <span className="font-bold text-lg">
          {item.quantity}
        </span>

        <button
          onClick={() =>
            increase(item.foodVariantId)
          }
          className="
            w-10
            h-10
            rounded-full
            bg-green-500
            text-white
          "
        >
          +
        </button>

      </div>
    </div>
  );
}