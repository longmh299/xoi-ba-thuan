export default function OrderSummary({
  totalItems,
  totalPrice,
  onCheckout,
}) {
  return (
    <div
      className="
        bg-white
        rounded-3xl
        shadow
        p-5
      "
    >
      <div className="flex justify-between">

        <span>Tổng món</span>

        <strong>{totalItems}</strong>

      </div>

      <div className="flex justify-between mt-3">

        <span>Tổng tiền</span>

        <strong className="text-green-600">

          {totalPrice.toLocaleString("vi-VN")}đ

        </strong>

      </div>

      <button
        onClick={onCheckout}
        className="
          mt-6
          w-full
          h-14
          rounded-2xl
          bg-green-600
          text-white
          font-bold
        "
      >
        ĐẶT HÀNG
      </button>

    </div>
  );
}