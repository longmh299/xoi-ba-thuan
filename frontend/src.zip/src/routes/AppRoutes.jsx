import {
    BrowserRouter,
    Navigate,
    Route,
    Routes,
} from "react-router-dom";
import DashboardPage from "../pages/admin/DashboardPage";
import LoginPage from "../pages/auth/LoginPage";
import RegisterPage from "../pages/auth/RegisterPage";
import CartPage from "../pages/customer/CartPage";
import HomePage from "../pages/customer/HomePage";
import ProtectedRoute from "./ProtectedRoute";
import AdminRoute from "./AdminRoute";
function MyOrdersPage() {
    return <h1>Đặt hàng thành công 🎉</h1>;
}
export default function AppRoutes() {
    return (
        <BrowserRouter>
            <Routes>
                <Route
                    path="/login"
                    element={<LoginPage />}
                />

                <Route
                    path="/"
                    element={
                        <ProtectedRoute>
                            <HomePage />
                        </ProtectedRoute>
                    }
                />

                <Route
                    path="/admin"
                    element={
                        <AdminRoute>
                            <DashboardPage />
                        </AdminRoute>
                    }
                />

                <Route
                    path="*"
                    element={
                        <Navigate
                            to="/login"
                        />
                    }
                />
                <Route
                    path="/register"
                    element={<RegisterPage />}
                />
                <Route
                    path="/cart"
                    element={
                        <ProtectedRoute>
                            <CartPage />

                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/my-orders"
                    element={
                        <ProtectedRoute>
                            <MyOrdersPage />
                        </ProtectedRoute>
                    }
                />
            </Routes>
        </BrowserRouter>
    );
}