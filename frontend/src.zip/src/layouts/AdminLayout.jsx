import { useState } from "react";

import AdminHeader from "../components/layout/AdminHeader";
import AdminDrawer from "../components/layout/AdminDrawer";

export default function AdminLayout({
  children,
}) {
  const [drawerOpen, setDrawerOpen] =
    useState(false);

  return (
    <div className="min-h-screen bg-slate-100">

      <AdminHeader
        onMenuClick={() =>
          setDrawerOpen(true)
        }
      />

      <AdminDrawer
        open={drawerOpen}
        onClose={() =>
          setDrawerOpen(false)
        }
      />

      <main className="max-w-md mx-auto p-4">
        {children}
      </main>

    </div>
  );
}