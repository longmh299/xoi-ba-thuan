import api from "./axios";

export function getHome() {
  return api.get("/home");
}