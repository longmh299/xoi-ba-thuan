import { useEffect, useState } from "react";

import VariantModal from "../../components/customer/VariantModal";
import { getHome } from "../../api/home.api";
import CartBar from "../../components/customer/CartBar";
import HomeHeader from "../../components/customer/HomeHeader";
import FoodCard from "../../components/customer/FoodCard";

export default function HomePage() {
    const [loading, setLoading] =
        useState(true);
    const [selectedFood, setSelectedFood] =
        useState(null);
    const [shop, setShop] =
        useState(null);

    const [categories, setCategories] =
        useState([]);

    const [foods, setFoods] =
        useState([]);

    async function loadHome() {
        try {
            const res = await getHome();

            const data = res.data.data;

            setShop(data.shop);
            setCategories(data.categories);
            setFoods(data.foods);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        loadHome();
    }, []);

    function handleAdd(food) {
        setSelectedFood(food);
    }

    if (loading) {
        return (
            <div className="flex items-center justify-center h-screen">
                Đang tải...
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-slate-100">

            {/* Header */}

            <HomeHeader shop={shop} />

            {/* Category */}

            <div
                className="
          flex
          gap-3
          overflow-x-auto
          px-4
          py-4
          scrollbar-hide
        "
            >
                {categories.map((category) => (
                    <button
                        key={category.id}
                        className="
              px-5
              py-2
              rounded-full
              bg-white
              shadow-sm
              whitespace-nowrap
              font-medium
            "
                    >
                        {category.name}
                    </button>
                ))}
            </div>

            {/* Food List */}

            <div className="p-4 space-y-5">
                {foods.map((food) => (
                    <FoodCard
                        key={food.id}
                        food={food}
                        onAdd={handleAdd}
                    />
                ))}
            </div>
            <VariantModal
                open={!!selectedFood}
                food={selectedFood}
                onClose={() =>
                    setSelectedFood(null)
                }  
            />
            <CartBar />
        </div>
    );
}
